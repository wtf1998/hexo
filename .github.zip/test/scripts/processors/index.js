'use strict';

describe('Processors', () => {
  require('./asset');
  require('./common');
  require('./data');
  require('./post');
});
