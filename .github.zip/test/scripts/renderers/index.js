'use strict';

describe('Renderers', () => {
  require('./json');
  require('./plain');
  require('./yaml');
  require('./nunjucks');
});
